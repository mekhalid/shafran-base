<?php
header("locationL ../");